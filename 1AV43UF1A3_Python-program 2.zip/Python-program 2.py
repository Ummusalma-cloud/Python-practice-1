#create word=python print first character last character and length
a = "Python"
print (a[0],a[-1],len(a))
#create word="rajathi" print the first charcter last character and length
b = "Rajathi"
print (b[0],b[-1],len(b))
#create first="good" and second="morning" concatenate them and print the result
first = "good"
second = "morning"
print(first+second)
#create word="hii" repeat it 3 times and print the result
c = "Hi"
print(c*3)
#create word="programming" print its character at index 0,index3,index-1
d = "programming"
print(d[0],d[3],d[-1])
#create city="tenkasi" print the city first character last character and length
city = "tenkasi"
print(city[0],city[-1],len(city))
#create symbol ="*" repeat it 5 times and print the result
symbol ="*"
print(symbol*5)
#create a="py" and b="thon" concatenate them and then print the length of the resulting string
a = "py"
b = "thon"
result=a+b
print(len(result))
#create name1="tenkasi" and name2="karaikudi" print both using a comma, then print the length of each string
name1 = "tenkasi"
name2 = "karaikudi"
print(name1,name2,sep=",")
print("lengths:",len(name1),len(name2))
#create word="hello" repeat the word twice print first character last character and length
s="Hello"
word =s*2
print(word,word[0],word[-1],len(word))