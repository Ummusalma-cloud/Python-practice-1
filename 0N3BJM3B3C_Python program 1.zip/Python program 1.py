#write python code to print hello world!
print("Hello world!")
#write python code to print welcome to python
print("Welcome to python")
#write python code to print your name
print("Ummu salma")
#write pyrhon code to print i am learning python
print("I am learning python")
#write python code to print python programming
print("Python programming")
#write python code to print good morning
print("Good morning")
#write python code to print welcome students
print("Welcome students")
#write python code to print python is easy
a="Python is easy"
print(a)
#write python code to print my first program
b="My first program"
print(b)
#write python code to print hello from python
print("Hello from python")